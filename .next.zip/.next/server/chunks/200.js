exports.id = 200;
exports.ids = [200];
exports.modules = {

/***/ 66888:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\(components)\\Navbar.tsx");


/***/ })

};
;