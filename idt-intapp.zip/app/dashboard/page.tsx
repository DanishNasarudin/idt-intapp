import React from "react";

type Props = {};

const Dashboard = (props: Props) => {
  return <div>Dashboard</div>;
};

export default Dashboard;
