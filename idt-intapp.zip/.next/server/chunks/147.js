exports.id = 147;
exports.ids = [147];
exports.modules = {

/***/ 98667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _components_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-icons/ri/index.esm.js
var index_esm = __webpack_require__(83751);
;// CONCATENATED MODULE: ./app/(hooks)/useScrollListener.tsx

function useScrollListener() {
    const [data, setData] = (0,react_.useState)({
        x: 0,
        y: 0,
        lastX: 0,
        lastY: 0,
        checkY: 0
    });
    // set up event listeners
    (0,react_.useEffect)(()=>{
        const handleScroll = ()=>{
            setData((last)=>{
                return {
                    x: window.scrollX,
                    y: window.scrollY,
                    lastX: last.x,
                    lastY: last.y,
                    checkY: window.scrollY - last.y
                };
            });
        };
        handleScroll();
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    return data;
}
const ScrollContext = /*#__PURE__*/ (/* unused pure expression or super */ null && (createContext(null)));

;// CONCATENATED MODULE: ./app/(components)/Navbar.tsx




function Navbar({}) {
    const [toggle, setToggle] = (0,react_.useState)(true);
    const [offerToggle, setOfferToggle] = (0,react_.useState)(false);
    const [careToggle, setCareToggle] = (0,react_.useState)(false);
    const scroll = useScrollListener();
    const [hideNavbar, setHideNavbar] = (0,react_.useState)(false);
    // console.log(scroll);
    (0,react_.useEffect)(()=>{
        if (scroll.checkY > 0) {
            setHideNavbar(true);
        } else if (scroll.checkY < 0) {
            setHideNavbar(false);
        }
    }, [
        scroll.y,
        scroll.lastY
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: `
        before:absolute before:w-full before:h-full before:content-[''] before:backdrop-blur-md before:top-0 before:-z-10
    bg-primary/80 sticky border-b-[1px] border-[#323232] z-50 transition-all top-0
    ${hideNavbar ? "translate-y-[-100%]" : ""}
    `,
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "      relative max-w-[1060px] mx-auto",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "   flex justify-between items-center w-full sm:w-4/5 px-4 sm:px-0 mx-auto text-xs py-4 z-20   sm:py-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "https://idealtech.com.my/wp-content/uploads/2023/03/IDT_LOGO-150x150.png",
                                alt: "logo",
                                className: "w-10 z-10"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `
            before:absolute before:w-full before:h-full before:content-[''] before:backdrop-blur-md before:top-0 before:-z-[10]
            sm:before:content-none
            ${toggle ? "hidden" : "flex"} flex-col absolute top-[99%] w-full text-center gap-8 left-0 py-8 bg-primary/50 border-y-[1px] border-white/10
            sm:relative sm:flex sm:flex-row sm:justify-between sm:pl-10 sm:w-full sm:py-0 sm:border-y-0 sm:bg-transparent`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://idealtech.com.my/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "h-full flex items-center justify-center",
                                            children: "Home"
                                        })
                                    })
                                }, "home"),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://idealtech.com.my/about-us/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "h-full flex items-center justify-center",
                                            children: "About"
                                        })
                                    })
                                }, "about"),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "flex items-center justify-center cursor-pointer",
                                            onClick: ()=>{
                                                setOfferToggle(!offerToggle);
                                                setCareToggle(false);
                                            },
                                            children: [
                                                "Special Offer",
                                                " ",
                                                offerToggle ? /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiArrowDropDownFill */.mEq, {
                                                    size: 20
                                                }) : /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiArrowDropLeftFill */.J28, {
                                                    size: 20
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: `
                sm:before:absolute sm:before:w-full sm:before:h-full sm:before:backdrop-blur-md sm:before:top-0 sm:before:left-0 sm:before:-z-[10] sm:mt-0
                ${offerToggle ? "sm:before:content-['']" : "sm:before:content-none"}
            relative py-0 translate-y-0 gap-8 flex flex-col border-white/0
            ${offerToggle ? "mt-8" : "mt-0"}
            ${offerToggle ? "sm:absolute" : "sm:hidden"}
            sm:primary/30 sm:py-10 sm:px-10 sm:-translate-x-[20%] sm:translate-y-[30%] sm:border-b-[1px] sm:border-white/10`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${offerToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/gaming-pcs/#rtx-geforce-pc",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "Package PC"
                                                        })
                                                    })
                                                }, "packagepc"),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${offerToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/workstation-pc/",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "Workstation PC"
                                                        })
                                                    })
                                                }, "workstationpc")
                                            ]
                                        })
                                    ]
                                }, "specialoffer"),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "flex items-center justify-center cursor-pointer",
                                            onClick: ()=>{
                                                setCareToggle(!careToggle);
                                                setOfferToggle(false);
                                            },
                                            children: [
                                                "Customer Care",
                                                " ",
                                                careToggle ? /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiArrowDropDownFill */.mEq, {
                                                    size: 20
                                                }) : /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiArrowDropLeftFill */.J28, {
                                                    size: 20
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: `
                sm:before:absolute sm:before:w-full sm:before:h-full sm:before:backdrop-blur-md sm:before:top-0 sm:before:left-0 sm:before:-z-[10] sm:mt-0
                ${careToggle ? "sm:before:content-['']" : "sm:before:content-none"}
                relative py-0 translate-y-0 gap-8 flex flex-col border-white/0
                ${careToggle ? "mt-8" : "mt-0"}
                ${careToggle ? "sm:absolute" : "sm:hidden"}
                sm:primary/30 sm:py-10 sm:px-10 sm:-translate-x-[30%] sm:translate-y-[20%] sm:border-b-[1px] sm:border-white/10`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${careToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/aeon-easy-payment/",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "AEON Easy Paymnent"
                                                        })
                                                    })
                                                }, "AEON"),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${careToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/terms-of-use/",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "Terms and Conditions"
                                                        })
                                                    })
                                                }, "terms"),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${careToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/warranty-info/",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "Warranty Services"
                                                        })
                                                    })
                                                }, "warranty"),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `
            ${careToggle ? "block" : "hidden"} h-full`,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "https://idealtech.com.my/cancellation-and-returns-policy/",
                                                        target: "_blank",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                            className: "h-full flex items-center justify-center",
                                                            children: "Cancellation & Refund Policy"
                                                        })
                                                    })
                                                }, "cancel")
                                            ]
                                        })
                                    ]
                                }, "customercare"),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://idealtech.com.my/contact-us/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "h-full flex items-center justify-center",
                                            children: "Contact Us"
                                        })
                                    })
                                }, "contact")
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiMenuLine */.B4m, {
                            color: "white",
                            size: 30,
                            className: `sm:hidden ${toggle ? "block" : "hidden"}`,
                            onClick: ()=>{
                                setToggle(!toggle);
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* RiCloseLine */.eSQ, {
                            color: "white",
                            size: 30,
                            className: `sm:hidden ${toggle ? "hidden" : "block"}`,
                            onClick: ()=>{
                                setToggle(!toggle);
                            }
                        })
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const _components_Navbar = (Navbar);


/***/ }),

/***/ 64974:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 67144, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 77914, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65110, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 23682, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31390, 23))

/***/ }),

/***/ 20012:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 30201));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98667))

/***/ }),

/***/ 43440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  "metadata": () => (/* binding */ metadata)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(83146);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(85035);
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/shared/lib/app-dynamic.js
var app_dynamic = __webpack_require__(68312);
var app_dynamic_default = /*#__PURE__*/__webpack_require__.n(app_dynamic);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(34212);
;// CONCATENATED MODULE: ./app/(components)/Footer.tsx


const Footer = (props)=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: " border-t-[1px] border-[#323232] text-[10px] text-zinc-400 py-2 px-4 text-center",
        children: "\xa9 [2018-2022] IDEAL TECH PC SDN BHD (1084329-M). All Rights Reserved."
    });
};
/* harmony default export */ const _components_Footer = (Footer);

// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(92817);
;// CONCATENATED MODULE: ./app/layout.tsx





const Navbar = app_dynamic_default()(()=>__webpack_require__.e(/* import() */ 200).then(__webpack_require__.t.bind(__webpack_require__, 66888, 23)), {
    loadableGenerated: {
        modules: [
            "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\layout.tsx -> " + "./(components)/Navbar"
        ]
    },
    ssr: false
});
const metadata = {
    title: "Ideal Tech PC Internal App",
    description: "Internal",
    icons: {
        icon: "/icon?<generated>"
    },
    appleWebApp: true
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ jsx_runtime.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("body", {
            className: `${(target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className} relative`,
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "mx-auto",
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime.jsx(_components_Footer, {})
            ]
        })
    });
}


/***/ }),

/***/ 72154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23854);
/* harmony import */ var next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_server_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20459);
/* harmony import */ var next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93869);
/* harmony import */ var next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__);
  
  
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const pathname = "/"
    const routeRegex = (0,next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__.getNamedRouteRegex)(pathname, false)
    const route = (0,next_dist_server_server_utils__WEBPACK_IMPORTED_MODULE_1__/* .interpolateDynamicPath */ .oE)(pathname, props.params, routeRegex)

    const imageData = {"type":"image/x-icon","sizes":"any"};

    return {
      ...imageData,
      url: next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0___default().join(route, "favicon.ico" + ""),
    }
  });

/***/ }),

/***/ 72759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23854);
/* harmony import */ var next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_server_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20459);
/* harmony import */ var next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93869);
/* harmony import */ var next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__);
  
  
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const pathname = "/"
    const routeRegex = (0,next_dist_shared_lib_router_utils_route_regex__WEBPACK_IMPORTED_MODULE_2__.getNamedRouteRegex)(pathname, false)
    const route = (0,next_dist_server_server_utils__WEBPACK_IMPORTED_MODULE_1__/* .interpolateDynamicPath */ .oE)(pathname, props.params, routeRegex)

    const imageData = {"type":"image/png","sizes":"1000x1000"};

    return {
      ...imageData,
      url: next_dist_shared_lib_isomorphic_path__WEBPACK_IMPORTED_MODULE_0___default().join(route, "icon.png" + "?79f18a794425276e"),
    }
  });

/***/ }),

/***/ 92817:
/***/ (() => {



/***/ })

};
;