(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 23854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/isomorphic/path");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 93869:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 91282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeReply": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.decodeReply),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(35120);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(76370);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55636)), "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72759))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43440)), "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72154))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72759))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
  }
        }
      ]
      }.children;
    const pages = ["D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\page.tsx"];

    
    
    
    

    

    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 71557:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 24468, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 34027, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1894));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 25784))

/***/ }),

/***/ 55636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(83146);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\page.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_page_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(64228);
var target_path_app_page_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_page_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(34212);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(62208);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(42585);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/hero-graphic.webp
/* harmony default export */ const hero_graphic = ({"src":"/_next/static/media/hero-graphic.0493be94.webp","height":1000,"width":1060,"blurDataURL":"data:image/webp;base64,UklGRoAAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDIAAAABYBPZtpPzc6Kl+pQ5t+ACRVhANHwPETEBlFWTEABX/XO+GaA6nhunCO3UT3MWlMUXAFZQOCAoAAAAkAEAnQEqCAAIAAJAOCWkAAKWR1jAAP6xqqh14c1wq9gy/mFpRAAAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/hero-graphic-mob.webp
/* harmony default export */ const hero_graphic_mob = ({"src":"/_next/static/media/hero-graphic-mob.ed5621b8.webp","height":1000,"width":1060,"blurDataURL":"data:image/webp;base64,UklGRnoAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDYAAAABf6CmkRQ4estb06IBSURECMyItLaxvYeaSJKiPr78rGAJF8TIwCEa8BHR/wAzwXq7n38HyARWUDggHgAAADABAJ0BKggACAACQDglpAADcAD+6wr8iHRmbfAAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./app/(sections)/Hero.tsx






const Hero = (props)=>{
    const imageSize = 300;
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full flex flex-col gap-4 item-center relative h-[100vh]",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "max-w-[1060px] mx-auto w-full flex gap-10 relative justify-center items-center py-8 pb-4 sm:py-8 md:py-[85px] sm:pb-24 md:pb-[150px] px-4 z-[5]   ",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "texts flex flex-col gap-4 items-center text-center max-w-[500px] w-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("h1", {
                            className: "leading-none",
                            children: [
                                "Ideal Tech PC ",
                                /*#__PURE__*/ jsx_runtime.jsx("br", {}),
                                " Internal App"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                            children: "Hopefully this helps."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex gap-4 mt-0 sm:mt-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "#positions",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                        className: "py-2 px-4 sm:py-4 sm:px-8 border-white border-[1px] rounded-lg w-fit mx-auto mobilehover:hover:bg-white/20 transition-all",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                            className: "text-[10px] sm:text-sm",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("b", {
                                                children: "Nothing Yet.."
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/warranty",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("button", {
                                        className: "py-2 px-4 sm:py-4 sm:px-8 border-transparent border-[1px] rounded-lg bg-accent mobilehover:hover:bg-accent/80 w-fit mx-auto transition-all",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                            className: "text-[10px] sm:text-sm",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("b", {
                                                children: "Warranty Entry"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "hidden sm:block bg-gradient-to-r from-transparent from-0% md:from-20% via-primary to-100% md:to-80% to-primary h-full w-full absolute z-[2]"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "hidden sm:block bg-gradient-to-r from-transparent from-0% md:from-20% via-primary to-100% md:to-80% to-primary h-full w-full absolute z-[2]"
            }),
            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                src: hero_graphic,
                alt: "bg-graphic",
                className: "absolute max-w-[800px] w-full top-[-180px] md:top-[-80px] left-[-170px] md:left-[100px] hidden sm:block opacity-90"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "block sm:hidden overflow-clip w-full h-[150px]",
                children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                    src: hero_graphic_mob,
                    alt: "bg-graphic",
                    className: "max-w-[800px] mt-[-320px] ml-[-180px] block sm:hidden opacity-90"
                })
            })
        ]
    });
};
/* harmony default export */ const _sections_Hero = (Hero);

;// CONCATENATED MODULE: ./app/page.tsx



function Home() {
    return /*#__PURE__*/ jsx_runtime.jsx("main", {
        className: `${(target_path_app_page_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className} flex flex-col mx-auto`,
        children: /*#__PURE__*/ jsx_runtime.jsx(_sections_Hero, {})
    });
}


/***/ }),

/***/ 1894:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hero-graphic-mob.ed5621b8.webp","height":1000,"width":1060,"blurDataURL":"data:image/webp;base64,UklGRnoAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDYAAAABf6CmkRQ4estb06IBSURECMyItLaxvYeaSJKiPr78rGAJF8TIwCEa8BHR/wAzwXq7n38HyARWUDggHgAAADABAJ0BKggACAACQDglpAADcAD+6wr8iHRmbfAAAA==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 25784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/hero-graphic.0493be94.webp","height":1000,"width":1060,"blurDataURL":"data:image/webp;base64,UklGRoAAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSDIAAAABYBPZtpPzc6Kl+pQ5t+ACRVhANHwPETEBlFWTEABX/XO+GaA6nhunCO3UT3MWlMUXAFZQOCAoAAAAkAEAnQEqCAAIAAJAOCWkAAKWR1jAAP6xqqh14c1wq9gy/mFpRAAAAA==","blurWidth":8,"blurHeight":8});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [961,740,27,907,147], () => (__webpack_exec__(91282)));
module.exports = __webpack_exports__;

})();