(() => {
var exports = {};
exports.id = 185;
exports.ids = [185];
exports.modules = {

/***/ 74146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 62418:
/***/ ((module) => {

"use strict";
module.exports = require("mysql2/promise");

/***/ }),

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 95232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 23854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/isomorphic/path");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 93869:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 32081:
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 71267:
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 84106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeReply": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.decodeReply),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(35120);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(79282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(75183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(15815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(76370);

    const tree = {
        children: [
        '',
        {
        children: [
        'warranty',
        {
        children: [
        '[branch]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 383, 23)), "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\warranty\\[branch]\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 14437)), "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\warranty\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72759))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43440)), "D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72154))).default(props)),(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 72759))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
  }
        }
      ]
      }.children;
    const pages = ["D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\warranty\\[branch]\\page.tsx"];

    
    
    
    

    

    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 96513:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'd6cd588d7514364776479c7661673ea59a4bad44': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["fetchData"]),
'259e2160cba5040835d2eb2223d9fb19c42b2546': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["updateData"]),
'026b647985a7041d6714a1b095d6b2d8bdb30183': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["addData"]),
'a55ea0dd0488cb9ddc99cb13ab894c7ca6f5dd4d': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["deleteData"]),
'456ce9565306f6b1aef3cbe0461daa5bd0d9701b': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["updateAllData"]),
'eaaa23b96a05268298b7d5054d656dd16c0f1332': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 92587)).then(mod => mod["moveData"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()

  if (action.$$with_bound === false) {
    return action.apply(null, args)
  }

  return action.call(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  'd6cd588d7514364776479c7661673ea59a4bad44': endpoint.bind(null, 'd6cd588d7514364776479c7661673ea59a4bad44'),
  '259e2160cba5040835d2eb2223d9fb19c42b2546': endpoint.bind(null, '259e2160cba5040835d2eb2223d9fb19c42b2546'),
  '026b647985a7041d6714a1b095d6b2d8bdb30183': endpoint.bind(null, '026b647985a7041d6714a1b095d6b2d8bdb30183'),
  'a55ea0dd0488cb9ddc99cb13ab894c7ca6f5dd4d': endpoint.bind(null, 'a55ea0dd0488cb9ddc99cb13ab894c7ca6f5dd4d'),
  '456ce9565306f6b1aef3cbe0461daa5bd0d9701b': endpoint.bind(null, '456ce9565306f6b1aef3cbe0461daa5bd0d9701b'),
  'eaaa23b96a05268298b7d5054d656dd16c0f1332': endpoint.bind(null, 'eaaa23b96a05268298b7d5054d656dd16c0f1332'),
}


/***/ }),

/***/ 23424:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-call-server.js
var app_call_server = __webpack_require__(20579);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-proxy.js
var action_proxy = __webpack_require__(9025);
;// CONCATENATED MODULE: ./app/(serverActions)/FetchDB.tsx



function __build_action__(action, args) {
  return (0,app_call_server.callServer)(action.$$id, args)
}

/* __next_internal_action_entry_do_not_use__ fetchData,updateData,addData,deleteData,updateAllData,moveData */ async function fetchData(...args) {
    return __build_action__(fetchData, args);
}
async function updateData(...args) {
    return __build_action__(updateData, args);
}
async function addData(...args) {
    return __build_action__(addData, args);
}
async function deleteData(...args) {
    return __build_action__(deleteData, args);
}
async function updateAllData(...args) {
    return __build_action__(updateAllData, args);
}
async function moveData(...args) {
    return __build_action__(moveData, args);
}

(0,action_proxy/* default */.Z)([
    fetchData,
    updateData,
    addData,
    deleteData,
    updateAllData,
    moveData
]);
fetchData.$$typeof = Symbol.for("react.server.reference");
fetchData.$$id = "d6cd588d7514364776479c7661673ea59a4bad44";
fetchData.$$bound = [];
fetchData.$$with_bound = false;
updateData.$$typeof = Symbol.for("react.server.reference");
updateData.$$id = "259e2160cba5040835d2eb2223d9fb19c42b2546";
updateData.$$bound = [];
updateData.$$with_bound = false;
addData.$$typeof = Symbol.for("react.server.reference");
addData.$$id = "026b647985a7041d6714a1b095d6b2d8bdb30183";
addData.$$bound = [];
addData.$$with_bound = false;
deleteData.$$typeof = Symbol.for("react.server.reference");
deleteData.$$id = "a55ea0dd0488cb9ddc99cb13ab894c7ca6f5dd4d";
deleteData.$$bound = [];
deleteData.$$with_bound = false;
updateAllData.$$typeof = Symbol.for("react.server.reference");
updateAllData.$$id = "456ce9565306f6b1aef3cbe0461daa5bd0d9701b";
updateAllData.$$bound = [];
updateAllData.$$with_bound = false;
moveData.$$typeof = Symbol.for("react.server.reference");
moveData.$$id = "eaaa23b96a05268298b7d5054d656dd16c0f1332";
moveData.$$bound = [];
moveData.$$with_bound = false;
 // const API_URL = "https://intapi.idealtech.com.my";
 // const API_KEY = process.env.DB_API_KEY || ""; // Replace with your actual API key
 // async function insertData(tableName: string, data: MyDataType): Promise<any> {
 //   const response = await fetch(`${API_URL}/insert/${tableName}`, {
 //     method: "POST",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //     body: JSON.stringify(data),
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }
 // async function updateData(
 //   tableName: string,
 //   id: number,
 //   data: Partial<MyDataType>
 // ): Promise<any> {
 //   const response = await fetch(`${API_URL}/update/${tableName}/${id}`, {
 //     method: "PUT",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //     body: JSON.stringify(data),
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }
 // async function deleteData(tableName: string, id: number): Promise<any> {
 //   const response = await fetch(`${API_URL}/delete/${tableName}/${id}`, {
 //     method: "DELETE",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }


// EXTERNAL MODULE: ./node_modules/@radix-ui/react-avatar/dist/index.mjs + 7 modules
var dist = __webpack_require__(19972);
// EXTERNAL MODULE: ./node_modules/clsx/dist/clsx.mjs
var clsx = __webpack_require__(95892);
// EXTERNAL MODULE: ./node_modules/tailwind-merge/dist/bundle-mjs.mjs
var bundle_mjs = __webpack_require__(87249);
;// CONCATENATED MODULE: ./lib/utils.ts


function cn(...inputs) {
    return (0,bundle_mjs/* twMerge */.m6)((0,clsx/* clsx */.W)(inputs));
}

;// CONCATENATED MODULE: ./(scn-components)/ui/avatar.tsx




const Avatar = /*#__PURE__*/ react_.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Root */.fC, {
        ref: ref,
        className: cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className),
        ...props
    }));
Avatar.displayName = dist/* Root.displayName */.fC.displayName;
const AvatarImage = /*#__PURE__*/ react_.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Image */.Ee, {
        ref: ref,
        className: cn("aspect-square h-full w-full", className),
        ...props
    }));
AvatarImage.displayName = dist/* Image.displayName */.Ee.displayName;
const AvatarFallback = /*#__PURE__*/ react_.forwardRef(({ className , ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* Fallback */.NY, {
        ref: ref,
        className: cn("flex h-full w-full items-center justify-center rounded-full bg-muted", className),
        ...props
    }));
AvatarFallback.displayName = dist/* Fallback.displayName */.NY.displayName;


;// CONCATENATED MODULE: ./app/warranty/(components)/TextBoxEditor.tsx


const TextBoxEditor = ({ boxSize , values , id , onInputChange , setOpenClose , openClose  })=>{
    // Open input box ----
    const inputRef = (0,react_.useRef)(null);
    // Copy values ----
    const [copyValues, setCopyValues] = (0,react_.useState)("");
    const [copyValuesH, setCopyValuesH] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        if (copyValues) {
            navigator.clipboard.writeText(String(copyValues));
            setCopyValues("");
        }
    }, [
        copyValues
    ]);
    // console.log(values);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `
                  max-w-[${boxSize}px] h-full
                  relative
                  ${openClose ? "" : "overflow-hidden"}
                  ${copyValuesH ? "[&>svg]:mobilehover:hover:fill-green-300 [&>svg]:mobilehover:hover:bg-green-700" : "[&>svg]:mobilehover:hover:fill-zinc-300 [&>svg]:mobilehover:hover:bg-zinc-700"}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                role: "button",
                className: "w-full px-2 py-1 cursor-default",
                onClick: ()=>{
                    setOpenClose(id, true);
                    setTimeout(()=>{
                        if (inputRef.current && inputRef.current.id === id) inputRef.current.focus();
                    }, 100);
                },
                children: [
                    values === null ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "min-h-[24px]"
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "min-h-[24px]",
                        children: values
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        role: "textbox",
                        "data-open": openClose,
                        className: "z-[2] data-[open=true]:block data-[open=false]:hidden absolute w-full h-full top-0 left-0 bg-zinc-800 flex items-center whitespace-normal",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-zinc-800 h-max w-full px-1 py-1 rounded-md whitespace-normal",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                ref: openClose ? inputRef : null,
                                id: id,
                                type: "text",
                                value: values === null ? " " : values,
                                onChange: (e)=>{
                                    onInputChange(e);
                                },
                                onKeyDown: (e)=>{
                                    if (e.key === "Enter" || e.key === "Escape") {
                                        setOpenClose(id, false);
                                    }
                                },
                                placeholder: " ",
                                className: "outline-none cursor-text w-full bg-zinc-800 text-white placeholder-gray-400"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                className: `
                      cursor-pointer w-6 h-6 py-1 rounded-md absolute top-0 right-0 translate-x-[-35%] translate-y-[15%]  transition-all
                      fill-transparent bg-transparent
                      `,
                onClick: ()=>{
                    setCopyValues(values ? values : "");
                    setCopyValuesH(true);
                    setTimeout(()=>{
                        setCopyValuesH(false);
                    }, 1000);
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M20 2H10c-1.103 0-2 .897-2 2v4H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2v-4h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zM4 20V10h10l.002 10H4zm16-6h-4v-4c0-1.103-.897-2-2-2h-4V4h10v10z"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M6 12h6v2H6zm0 4h6v2H6z"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const _components_TextBoxEditor = (TextBoxEditor);

;// CONCATENATED MODULE: ./app/warranty/(components)/TextBoxNormal.tsx


const TextBoxNormal = ({ id , title , input , area , areaSize , onInputChange  })=>{
    // Copy values ----
    const [copyValues, setCopyValues] = (0,react_.useState)("");
    const [copyValuesH, setCopyValuesH] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        if (copyValues) {
            navigator.clipboard.writeText(String(copyValues));
            setCopyValues("");
        }
    }, [
        copyValues
    ]);
    if (area) return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "z-[1] flex flex-col gap-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-zinc-400",
                children: title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `
        ${copyValuesH ? "[&>svg]:mobilehover:hover:fill-green-300 [&>svg]:mobilehover:hover:bg-green-700" : "[&>svg]:mobilehover:hover:fill-zinc-300 [&>svg]:mobilehover:hover:bg-zinc-700"}
      relative`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        placeholder: " ",
                        className: `
                  bg-transparent border-[1px] border-zinc-800 outline-none rounded-md resize-none
                  px-2 py-1 h-[${areaSize}] w-full
            `,
                        id: id,
                        value: input === null ? " " : input,
                        onChange: (e)=>{
                            onInputChange(e);
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        className: `
          
                          cursor-pointer w-6 h-6 py-1 rounded-md absolute top-0 right-0 translate-x-[-35%] translate-y-[15%]  transition-all
                          fill-transparent bg-transparent
                          `,
                        onClick: ()=>{
                            setCopyValues(input ? input : "");
                            setCopyValuesH(true);
                            setTimeout(()=>{
                                setCopyValuesH(false);
                            }, 1000);
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M20 2H10c-1.103 0-2 .897-2 2v4H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2v-4h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zM4 20V10h10l.002 10H4zm16-6h-4v-4c0-1.103-.897-2-2-2h-4V4h10v10z"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M6 12h6v2H6zm0 4h6v2H6z"
                            })
                        ]
                    })
                ]
            })
        ]
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `z-[1]
    flex flex-col gap-2`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-zinc-400",
                children: title
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `
      ${copyValuesH ? "[&>svg]:mobilehover:hover:fill-green-300 [&>svg]:mobilehover:hover:bg-green-700" : "[&>svg]:mobilehover:hover:fill-zinc-300 [&>svg]:mobilehover:hover:bg-zinc-700"}
      relative`,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: "text",
                        placeholder: " ",
                        className: "   bg-transparent border-[1px] border-zinc-800 outline-none rounded-md w-full   px-2 py-1   ",
                        id: id,
                        value: input === null ? " " : input,
                        onChange: (e)=>{
                            onInputChange(e);
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        width: "24",
                        height: "24",
                        viewBox: "0 0 24 24",
                        className: `
          
                          cursor-pointer w-6 h-6 py-1 rounded-md absolute top-0 right-0 translate-x-[-35%] translate-y-[15%]  transition-all
                          fill-transparent bg-transparent
                          `,
                        onClick: ()=>{
                            setCopyValues(input ? input : "");
                            setCopyValuesH(true);
                            setTimeout(()=>{
                                setCopyValuesH(false);
                            }, 1000);
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M20 2H10c-1.103 0-2 .897-2 2v4H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h10c1.103 0 2-.897 2-2v-4h4c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zM4 20V10h10l.002 10H4zm16-6h-4v-4c0-1.103-.897-2-2-2h-4V4h10v10z"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M6 12h6v2H6zm0 4h6v2H6z"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const _components_TextBoxNormal = (TextBoxNormal);

// EXTERNAL MODULE: ./node_modules/socket.io-client/build/esm-debug/index.js + 27 modules
var esm_debug = __webpack_require__(53133);
;// CONCATENATED MODULE: ./lib/socket.ts

const hostname =  false ? 0 : `https://intapi.idealtech.com.my`;
const socket = (0,esm_debug.io)(`${hostname}`);
/* harmony default export */ const lib_socket = (socket);

// EXTERNAL MODULE: ./node_modules/html2pdf.js/dist/html2pdf.js
var html2pdf = __webpack_require__(39450);
var html2pdf_default = /*#__PURE__*/__webpack_require__.n(html2pdf);
;// CONCATENATED MODULE: ./app/warranty/(components)/TableRowExt.tsx





const TableRowExt = ({ data , onInputChange , deleteDB , openCloseTab , isExtEmpty , updateAllDB  })=>{
    const [deleteCon, setDeleteCon] = (0,react_.useState)(false);
    // Copy all data ----
    const [copyValuesH, setCopyValuesH] = (0,react_.useState)(false);
    const copyAllData = async (data)=>{
        try {
            setCopyValuesH(true);
            const dataString = Object.entries(data).map(([key, value])=>`${key}: ${value === null ? "" : value}`).join("\n");
            await navigator.clipboard.writeText(dataString);
        // console.log("Data copied to clipboard");
        } catch (error) {
            console.error("Failed to copy data to clipboard", error);
        } finally{
            setTimeout(()=>{
                setCopyValuesH(false);
            }, 1000);
        }
    };
    // Print or Download PDF
    // const pdfRef = useRef<HTMLDivElement>(null);
    const [downloadPDFVisual, setDownloadPDFVisual] = (0,react_.useState)(false);
    // console.log(data);
    const downloadPDF = async ()=>{
        try {
            setDownloadPDFVisual(true);
            const response = await fetch("/serviceReceipt.html");
            let template = await response.text();
            template = template.replace("{{service_no}}", data.service_no ? data.service_no : "");
            template = template.replace("{{name}}", data.name ? data.name : "");
            template = template.replace("{{contact}}", data.contact ? data.contact : "");
            template = template.replace("{{email}}", data.email ? data.email : "");
            template = template.replace("{{address}}", data.address ? data.address : "");
            template = template.replace("{{received_items}}", data.received_items ? data.received_items : "");
            template = template.replace("{{purchase_date}}", data.purchase_date ? data.purchase_date : "");
            template = template.replace("{{invoice}}", data.invoice ? data.invoice : "");
            template = template.replace("{{issues}}", data.issues ? data.issues.replace(/\n/g, "<br>") : "");
            template = template.replace("{{solutions}}", data.solutions ? data.solutions.replace(/\n/g, "<br>") : "");
            template = template.replace("{{pic}}", data.pic ? data.pic : "");
            template = template.replace("{{date}}", data.date ? data.date : "");
            const parser = new DOMParser();
            const doc = parser.parseFromString(template, "text/html");
            const element = doc.body;
            var opt = {
                margin: 8,
                image: {
                    type: "jpeg",
                    quality: 1
                }
            };
            html2pdf_default()().from(element).set(opt).toPdf().save("IdealTechPC_Service.pdf").then(()=>{
                document.body.removeChild(element);
            });
            setTimeout(()=>{
                setDownloadPDFVisual(false);
            }, 1000);
        // console.log("pass2");
        } catch (error) {
            console.error("Failed to generate PDF", error);
        }
    };
    // Send email of the invoice ----
    const sendEmail = async ()=>{
        try {
            const response = await fetch("/serviceReceipt.html");
            let template = await response.text();
            template = template.replace("{{service_no}}", data.service_no ? data.service_no : "");
            template = template.replace("{{name}}", data.name ? data.name : "");
            template = template.replace("{{contact}}", data.contact ? data.contact : "");
            template = template.replace("{{email}}", data.email ? data.email : "");
            template = template.replace("{{address}}", data.address ? data.address : "");
            template = template.replace("{{received_items}}", data.received_items ? data.received_items : "");
            template = template.replace("{{purchase_date}}", data.purchase_date ? data.purchase_date : "");
            template = template.replace("{{invoice}}", data.invoice ? data.invoice : "");
            template = template.replace("{{issues}}", data.issues ? data.issues.replace(/\n/g, "<br>") : "");
            template = template.replace("{{solutions}}", data.solutions ? data.solutions.replace(/\n/g, "<br>") : "");
            template = template.replace("{{pic}}", data.pic ? data.pic : "");
            template = template.replace("{{date}}", data.date ? data.date : "");
            await fetch("/api/contact", {
                method: "POST",
                body: JSON.stringify({
                    template: template,
                    values: data
                }),
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json"
                }
            });
        } catch (error) {
            console.error("Failed to generate PDF", error);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "rowext",
        className: "overflow-hidden pt-1 pb-2",
        children: [
            data && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex gap-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col1 w-full flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: false,
                                areaSize: "0",
                                id: "email",
                                title: "Email",
                                input: data.email,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: true,
                                areaSize: "120px",
                                id: "address",
                                title: "Address",
                                input: data.address,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: false,
                                areaSize: "0",
                                id: "purchase_date",
                                title: "Purchase Date",
                                input: data.purchase_date,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: false,
                                areaSize: "0",
                                id: "invoice",
                                title: "Invoice",
                                input: data.invoice,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: false,
                                areaSize: "0",
                                id: "received_items",
                                title: "Received Items",
                                input: data.received_items,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: false,
                                areaSize: "0",
                                id: "pin",
                                title: "PIN / Pass",
                                input: data.pin,
                                onInputChange: onInputChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col2 w-full flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: true,
                                areaSize: "150px",
                                id: "issues",
                                title: "Issues",
                                input: data.issues,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: true,
                                areaSize: "150px",
                                id: "solutions",
                                title: "Solutions",
                                input: data.solutions,
                                onInputChange: onInputChange
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col3 w-full flex flex-col gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: true,
                                areaSize: "150px",
                                id: "status_desc",
                                title: "Status Desc (Pending)",
                                input: data.status_desc,
                                onInputChange: onInputChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxNormal, {
                                area: true,
                                areaSize: "150px",
                                id: "remarks",
                                title: "Remarks / Accessories",
                                input: data.remarks,
                                onInputChange: onInputChange
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "buttons flex justify-between pt-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: `
            ${downloadPDFVisual ? "border-green-600 text-green-600 mobilehover:hover:border-green-400 mobilehover:hover:text-green-400" : "border-zinc-600 text-zinc-600 mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400"}
                              px-4 py-2 rounded-md transition-all border-[1px]
                              bg-transparent 
                              `,
                                onClick: ()=>downloadPDF(),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: downloadPDFVisual ? "Downloading.." : "Print PDF"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: `
            ${copyValuesH ? "border-green-600 text-green-600 mobilehover:hover:border-green-400 mobilehover:hover:text-green-400" : "border-zinc-600 text-zinc-600 mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400"}
                              px-4 py-2 rounded-md transition-all border-[1px]
                              bg-transparent
                              `,
                                onClick: ()=>copyAllData(data),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: copyValuesH ? "Copied!" : "Copy"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                disabled: data.email === "" || data.email === null,
                                className: `
            ${data.email === "" || data.email === null ? "border-zinc-800 text-zinc-800" : "border-zinc-600 text-zinc-600 mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400"}
                              px-4 py-2 rounded-md transition-all border-[1px]
                              bg-transparent 
                              `,
                                onClick: ()=>sendEmail(),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Send Email"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                disabled: isExtEmpty,
                                className: `
            ${isExtEmpty ? "bg-transparent border-zinc-800 text-zinc-800" : "bg-transparent border-accent text-accent mobilehover:hover:bg-accent/80 mobilehover:hover:text-white mobilehover:hover:border-white"}
                              px-4 py-2 rounded-md transition-all border-[1px]
                              `,
                                onClick: ()=>{
                                    updateAllDB();
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Save Data"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: `
                          px-4 py-2 rounded-md transition-all border-[1px]
                          bg-transparent border-red-600/70 text-red-600/70
                          mobilehover:hover:border-red-400 mobilehover:hover:text-red-400`,
                        onClick: ()=>{
                            setDeleteCon(true);
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Delete"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                "data-open": deleteCon,
                className: "data-[open=true]:block data-[open=false]:hidden fixed z-[2] bg-black/50 w-[100vw] h-[100vh] top-0 left-0",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "   max-w-[500px] bg-zinc-900 border-zinc-700 border-[1px] p-8 rounded-md m-auto translate-y-[150%]   flex flex-col gap-4   ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: "Are you sure you want to delete this Data?"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "This action cannot be undone. This will permanently delete the data from our servers."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-2 justify-end",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `
                              px-4 py-2 rounded-md transition-all border-[1px]
                              bg-transparent border-zinc-600/70 text-zinc-600/70
                              mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400`,
                                    onClick: ()=>setDeleteCon(false),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Cancel"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: `
                              px-4 py-2 rounded-md transition-all border-[1px]
                              bg-transparent border-red-600/70 text-red-600/70
                              mobilehover:hover:border-red-400 mobilehover:hover:text-red-400`,
                                    onClick: ()=>{
                                        if (data.service_no) deleteDB(data.service_no);
                                        setTimeout(()=>{
                                            setDeleteCon(false);
                                            openCloseTab(false);
                                            lib_socket.emit("re-render", {
                                                string: "render"
                                            });
                                        }, 50);
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Delete"
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const _components_TableRowExt = (TableRowExt);

;// CONCATENATED MODULE: ./app/warranty/(components)/Dropdown.tsx


const Dropdown = ({ boxSize , id , buttonId , status , values , setOpenClose , openClose , setInputValues , updateDB , clearExtRef  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        role: "button",
        className: `max-w-[${boxSize}px] whitespace-nowrap relative px-2 py-1`,
        onClick: ()=>setOpenClose(buttonId, true),
        children: [
            status && status.map((status, key)=>{
                if (status.type === values) return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    role: "button",
                    className: `rounded-md w-max px-2 ${status.color}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: values
                    })
                }, key);
            }),
            openClose && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "z-[2] absolute w-full left-0 top-0 py-2 flex flex-col rounded-md bg-zinc-800",
                children: status && status.map((status, key)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        role: "button",
                        className: "row-cont px-2 py-1 mobilehover:hover:bg-zinc-700",
                        onClick: ()=>{
                            setInputValues((prev)=>{
                                return {
                                    ...prev,
                                    values: {
                                        ...prev.values,
                                        [buttonId]: status.type
                                    }
                                };
                            });
                            updateDB(id ? id : "", buttonId, status.type);
                            setTimeout(()=>{
                                clearExtRef();
                                setOpenClose(buttonId, false);
                            }, 50);
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${status.color} rounded-md w-max leading-none px-2 py-[2px]`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: status.type
                            })
                        })
                    }, key);
                })
            })
        ]
    });
};
/* harmony default export */ const _components_Dropdown = (Dropdown);

;// CONCATENATED MODULE: ./app/warranty/(components)/TableRow.tsx






const TableRow = ({ branch , data , updateDB , deleteDB , updateAllDB , setNewEntry , lockTable  })=>{
    const initialInputState = {
        values: {
            service_no: data.service_no,
            date: data.date,
            pic: data.pic,
            name: data.name,
            contact: data.contact,
            status: data.status,
            email: data.email,
            address: data.address,
            purchase_date: data.purchase_date,
            invoice: data.invoice,
            received_items: data.received_items,
            pin: data.pin,
            issues: data.issues,
            solutions: data.solutions,
            status_desc: data.status_desc,
            remarks: data.remarks
        }
    };
    const [inputValues, setInputValues] = (0,react_.useState)(initialInputState);
    const { values  } = inputValues;
    (0,react_.useEffect)(()=>{
        setInputValues({
            values: {
                service_no: data.service_no,
                date: data.date,
                pic: data.pic,
                name: data.name,
                contact: data.contact,
                status: data.status,
                email: data.email,
                address: data.address,
                purchase_date: data.purchase_date,
                invoice: data.invoice,
                received_items: data.received_items,
                pin: data.pin,
                issues: data.issues,
                solutions: data.solutions,
                status_desc: data.status_desc,
                remarks: data.remarks
            }
        });
    }, [
        data
    ]);
    // console.log(values, "check");
    // last change for individual cells
    const lastChangedRef = (0,react_.useRef)({
        column: null,
        value: null
    });
    // last change for extended fields
    const lastChangedExtRef = (0,react_.useRef)({
        service_no: null,
        date: null,
        pic: null,
        name: null,
        contact: null,
        status: null,
        email: null,
        address: null,
        purchase_date: null,
        invoice: null,
        received_items: null,
        pin: null,
        issues: null,
        solutions: null,
        status_desc: null,
        remarks: null
    });
    // console.log(lastChangedExtRef);
    const prevValuesRef = (0,react_.useRef)(values);
    (0,react_.useEffect)(()=>{
        // console.log("pass");
        setLastChangeUpdated(!lastChangeUpdated);
        const changes = {};
        Object.keys(values).forEach((key)=>{
            if (values[key] !== prevValuesRef.current[key]) {
                changes[key] = values[key];
            }
        });
        if (Object.keys(changes).length > 0) {
            lastChangedExtRef.current = {
                ...lastChangedExtRef.current,
                ...changes
            };
        }
        prevValuesRef.current = values;
    }, [
        values
    ]);
    // console.log(lastChanged, "last change");
    const inputChange = ({ target  })=>{
        // console.log(target.value, "check");
        setInputValues((prev)=>({
                ...prev,
                values: {
                    ...prev.values,
                    [target.id]: target.value
                }
            }));
        // lastChangedExtRef.current = {
        //   ...lastChangedExtRef.current,
        //   [target.id]: target.value,
        // };
        const updatedLastChanged = {
            column: String(target.id),
            value: String(target.value)
        };
        // setLastChanged(updatedLastChanged);
        lastChangedRef.current = updatedLastChanged;
    };
    // Check if lastChangedExtRef is empty ----
    const [lastChangeUpdated, setLastChangeUpdated] = (0,react_.useState)(false);
    const isExtEmpty = (refObject)=>{
        for (const key of Object.keys(refObject)){
            if (refObject[key] !== null) {
                return true;
            }
        }
        return false;
    };
    // update All DB and reset lastChangedExtRef ----
    const handleUpdateAllDB = async ()=>{
        if (data.service_no) await updateAllDB(data.service_no, lastChangedExtRef.current);
        clearExtRef();
    };
    const clearExtRef = ()=>{
        // Update to clear last change for Ext
        const keys = Object.keys(lastChangedExtRef.current);
        keys.forEach((key)=>{
            lastChangedExtRef.current[key] = null;
        });
        setLastChangeUpdated(!lastChangeUpdated);
    };
    // OpenClose for bottom box ----
    const [accordion, setAccordion] = (0,react_.useState)(false);
    const [openTab, setOpenTab] = (0,react_.useState)(false);
    // OpenClose for Row ----
    const [openClose, setOpenClose] = (0,react_.useState)({
        status: false,
        pic: false,
        name: false,
        contact: false,
        service_no: false
    });
    const handleOpenClose = (id, open)=>{
        // console.log(id, open, "check");
        setOpenClose({
            ...openClose,
            [id]: open
        });
        if (open) {
            lib_socket.emit("lock-row", {
                lock: data.service_no
            });
        // console.log("lock handleOpenClose");
        } else {
            lib_socket.emit("unlock-row", {
                lock: data.service_no
            });
        // console.log("un lock handleOpenClose");
        }
        const lastChange = lastChangedRef.current;
        if (lastChange.column != null && lastChange.value != null) {
            // console.log("pass");
            if (values.service_no != null && values.service_no != "") updateDB(values.service_no, lastChange.column, lastChange.value);
            lastChangedRef.current = {
                column: null,
                value: null
            };
        }
    };
    //   console.log(openClose);
    // Handle outside click for all OpenClose Elements ----
    const openRef = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        const handleOutsideClick = (e)=>{
            if (openRef.current && openRef.current.contains(e.target)) {
                setOpenClose({
                    ...openClose
                });
                setTimeout(()=>{
                    lib_socket.emit("unlock-row", {
                        lock: data.service_no
                    });
                // console.log("unlock outsideclick");
                }, 50);
                // Update DB with the changes, take values and pass to parent to DB.
                const lastChange = lastChangedRef.current;
                if (lastChange.column != null && lastChange.value != null) {
                    // console.log("pass");
                    if (values.service_no != null && values.service_no != "") updateDB(values.service_no, lastChange.column, lastChange.value);
                    lastChangedRef.current = {
                        column: null,
                        value: null
                    };
                }
                clearExtRef();
            }
        };
        window.addEventListener("mousedown", handleOutsideClick);
        return ()=>{
            window.removeEventListener("mousedown", handleOutsideClick);
        };
    }, [
        openRef
    ]);
    // ----
    // const populateTemplateWithData = (template: string, data: DataValues) => {
    //   template = template.replace("{{name}}", data.name);
    // };
    // Socket io
    const [lockRow, setLockRow] = (0,react_.useState)(false);
    // const [lockRowOther, setLockRowOther] = useState(false);
    (0,react_.useEffect)(()=>{
        const handleLockRow = ({ lock  })=>{
            if (lock === "" || lock === null) return;
            if (lock === data.service_no) setLockRow(true);
        };
        const handleUnlockRow = ({ lock  })=>{
            if (lock === "" || lock === null) return;
            if (lock === data.service_no) setLockRow(false);
        };
        lib_socket.on("lock-row", handleLockRow);
        lib_socket.on("unlock-row", handleUnlockRow);
        return ()=>{
            lib_socket.off("lock-row", handleLockRow);
            lib_socket.off("unlock-row", handleUnlockRow);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "tab-row border-t-[1px] border-zinc-800 relative   data-[open=true]:bg-zinc-900 data-[open=false]:bg-transparent",
        "data-open": accordion,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                disabled: lockTable || lockRow,
                className: `
                  ${openTab && !lockTable ? "bg-zinc-700 mobilehover:hover:bg-accent/80 text-zinc-300 cursor-pointer" : "bg-transparent text-transparent cursor-default"}
                  absolute left-[-58px]
                          px-2 py-1 rounded-md transition-all border-[1px]
                          border-transparent`,
                onMouseEnter: ()=>setOpenTab(true),
                onMouseLeave: ()=>setOpenTab(false),
                onClick: ()=>{
                    setAccordion(!accordion);
                    if (accordion) {
                        handleUpdateAllDB();
                        lib_socket.emit("unlock-row", {
                            lock: data.service_no
                        });
                    } else {
                        lib_socket.emit("lock-row", {
                            lock: data.service_no
                        });
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: accordion ? "Close" : "Open"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tab-row-top w-full flex [&>div]:w-full [&>div]:border-l-[1px] [&>div]:border-zinc-800 whitespace-nowrap",
                onMouseEnter: ()=>setOpenTab(true),
                onMouseLeave: ()=>setOpenTab(false),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[100px] !border-l-[0px] overflow-hidden px-2 py-1",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: values.date
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxEditor, {
                        boxSize: 120,
                        values: values.service_no,
                        id: "service_no",
                        onInputChange: inputChange,
                        setOpenClose: handleOpenClose,
                        openClose: openClose.service_no
                    }),
                    branch && /*#__PURE__*/ jsx_runtime_.jsx(_components_Dropdown, {
                        boxSize: 110,
                        id: values.service_no,
                        buttonId: "pic",
                        status: branch.pic,
                        values: values.pic,
                        setOpenClose: handleOpenClose,
                        openClose: openClose.pic,
                        setInputValues: setInputValues,
                        updateDB: updateDB,
                        clearExtRef: clearExtRef
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxEditor, {
                        boxSize: 9999,
                        values: values.name,
                        id: "name",
                        onInputChange: inputChange,
                        setOpenClose: handleOpenClose,
                        openClose: openClose.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(_components_TextBoxEditor, {
                        boxSize: 160,
                        values: values.contact,
                        id: "contact",
                        onInputChange: inputChange,
                        setOpenClose: handleOpenClose,
                        openClose: openClose.contact
                    }),
                    branch && /*#__PURE__*/ jsx_runtime_.jsx(_components_Dropdown, {
                        boxSize: 160,
                        id: values.service_no,
                        buttonId: "status",
                        status: branch.status,
                        values: values.status,
                        setOpenClose: handleOpenClose,
                        openClose: openClose.status,
                        setInputValues: setInputValues,
                        updateDB: updateDB,
                        clearExtRef: clearExtRef
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "   tab-row-bot grid   px-2 data-[open=true]:py-1 data-[open=false]:py-0   data-[open=true]:h-auto data-[open=false]:h-0   data-[open=true]:grid-rows-[1fr] data-[open=false]:grid-rows-[0fr] transition-all   border-t-[1px] data-[open=true]:border-zinc-800 data-[open=false]:border-transparent overflow-hidden   ",
                "data-open": accordion,
                children: /*#__PURE__*/ jsx_runtime_.jsx(_components_TableRowExt, {
                    onInputChange: inputChange,
                    data: values,
                    deleteDB: deleteDB,
                    updateAllDB: handleUpdateAllDB,
                    openCloseTab: setAccordion,
                    isExtEmpty: !isExtEmpty(lastChangedExtRef.current)
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                "data-open": lockRow,
                className: "data-[open=true]:block data-[open=false]:hidden z-[3] absolute bg-red-800/20 w-full h-full left-0 top-0"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                "data-open": Object.values(openClose).some((value)=>value === true),
                ref: openRef,
                className: "data-[open=true]:block data-[open=false]:hidden fixed z-[1] bg-transparent w-[100vw] h-[100vh] top-0 left-0"
            })
        ]
    });
};
/* harmony default export */ const _components_TableRow = (TableRow);

;// CONCATENATED MODULE: ./app/warranty/(sections)/Tables.tsx



const Tables = ({ id , branch , data , updateDB , deleteDB , updateAllDB , setNewEntry , page , handleSetPage , lockTable  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "tab-container py-2",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tab-head flex [&>div]:w-full [&>div]:px-2 [&>div]:py-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[100px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Date"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[120px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Service No"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[110px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "PIC"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[9999px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Name"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[160px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Contact"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "max-w-[160px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Status"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "tab-body relative min-h-[336px]",
                children: [
                    data && data.map((row)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(_components_TableRow, {
                            branch: branch,
                            data: row,
                            updateDB: updateDB,
                            deleteDB: deleteDB,
                            updateAllDB: updateAllDB,
                            setNewEntry: setNewEntry,
                            lockTable: lockTable
                        }, row.service_no);
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `${lockTable ? "block" : "hidden"} z-[3] absolute w-full h-full bg-zinc-800/50 top-0 left-0`
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-4 justify-end pt-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: `border-[1px] pl-4 rounded-md overflow-hidden
              bg-transparent border-zinc-600 text-zinc-600
            flex gap-2 items-center
            `,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: "text-zinc-600 cursor-default",
                                children: [
                                    page.pageSize,
                                    " Rows"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: `flex flex-col`,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: ()=>{
                                            if (page.pageSize < 50) handleSetPage(id, {
                                                ...page,
                                                pageSize: page.pageSize + 10
                                            });
                                            setNewEntry((prev)=>!prev);
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "20",
                                            viewBox: "0 0 24 18",
                                            className: `px-1 
                    transition-all
                    fill-zinc-600
                    mobilehover:hover:bg-zinc-400
                    `,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m6.293 13.293 1.414 1.414L12 10.414l4.293 4.293 1.414-1.414L12 7.586z"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: ()=>{
                                            if (page.pageSize > 10) handleSetPage(id, {
                                                ...page,
                                                pageSize: page.pageSize - 10
                                            });
                                            setNewEntry((prev)=>!prev);
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "20",
                                            viewBox: "0 0 24 18",
                                            className: `px-1
                    transition-all rotate-180
                    fill-zinc-600
                    mobilehover:hover:bg-zinc-400
                    `,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m6.293 13.293 1.414 1.414L12 10.414l4.293 4.293 1.414-1.414L12 7.586z"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !(page.pageNum - 1 > 0),
                        className: `
                          px-4 py-2 rounded-md transition-all border-[1px]
                          bg-transparent 
                          ${!(page.pageNum - 1 > 0) ? "border-zinc-800 text-zinc-800" : "border-zinc-600 text-zinc-600 mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400"}`,
                        onClick: ()=>{
                            if (page.pageNum - 1 > 0) handleSetPage(id, {
                                ...page,
                                pageNum: page.pageNum - 1
                            });
                            setNewEntry((prev)=>!prev);
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Previous"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        disabled: !(page.pageNum < Math.floor(page.count / page.pageSize) + 1),
                        className: `
                          px-4 py-2 rounded-md transition-all border-[1px]
                          bg-transparent
                          ${!(page.pageNum < Math.floor(page.count / page.pageSize) + 1) ? "border-zinc-800 text-zinc-800" : "border-zinc-600 text-zinc-600 mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400"}`,
                        onClick: ()=>{
                            if (page.pageNum < Math.floor(page.count / page.pageSize) + 1) handleSetPage(id, {
                                ...page,
                                pageNum: page.pageNum + 1
                            });
                            setNewEntry((prev)=>!prev);
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "Next"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const _sections_Tables = (Tables);

// EXTERNAL MODULE: ./node_modules/use-debounce/dist/index.module.js
var index_module = __webpack_require__(20238);
;// CONCATENATED MODULE: ./app/warranty/[branch]/page.tsx








const branchFormat = {
    branch: [
        {
            id: "ampang-hq",
            data_local: "ap_local",
            data_other: "ap_other",
            name: "Ampang HQ",
            status: [
                {
                    type: "Pending",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Completed",
                    color: "bg-emerald-600 text-emerald-100"
                },
                {
                    type: "Pass SS2",
                    color: "bg-red-600 text-red-100"
                },
                {
                    type: "From SS2",
                    color: "bg-cyan-600 text-cyan-100"
                },
                {
                    type: "Pass Setia Alam",
                    color: "bg-orange-600 text-orange-100"
                },
                {
                    type: "From Setia Alam",
                    color: "bg-blue-600 text-blue-100"
                },
                {
                    type: "Pass JB",
                    color: "bg-amber-600 text-amber-100"
                },
                {
                    type: "From JB",
                    color: "bg-indigo-600 text-indigo-100"
                }
            ],
            pic: [
                {
                    type: "Hanif",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Anthony",
                    color: "bg-emerald-600 text-emerald-100"
                },
                {
                    type: "Hafiz",
                    color: "bg-red-600 text-red-100"
                },
                {
                    type: "Khai",
                    color: "bg-cyan-600 text-cyan-100"
                },
                {
                    type: "Dixon",
                    color: "bg-orange-600 text-orange-100"
                }
            ]
        },
        {
            id: "ss2-pj",
            data_local: "s2_local",
            data_other: "s2_other",
            name: "SS2, PJ",
            status: [
                {
                    type: "Pending",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Completed",
                    color: "bg-emerald-600 text-emerald-100"
                },
                {
                    type: "Pass Ampang",
                    color: "bg-red-600 text-red-100"
                },
                {
                    type: "From Ampang",
                    color: "bg-cyan-600 text-cyan-100"
                },
                {
                    type: "Pass Setia Alam",
                    color: "bg-orange-600 text-orange-100"
                },
                {
                    type: "From Setia Alam",
                    color: "bg-blue-600 text-blue-100"
                }
            ],
            pic: [
                {
                    type: "John",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Richard",
                    color: "bg-emerald-600 text-emerald-100"
                }
            ]
        },
        {
            id: "setia-alam",
            data_local: "sa_local",
            data_other: "sa_other",
            name: "Setia Alam",
            status: [
                {
                    type: "Pending",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Completed",
                    color: "bg-emerald-600 text-emerald-100"
                },
                {
                    type: "Pass Ampang",
                    color: "bg-red-600 text-red-100"
                },
                {
                    type: "From Ampang",
                    color: "bg-cyan-600 text-cyan-100"
                },
                {
                    type: "Pass SS2",
                    color: "bg-orange-600 text-orange-100"
                },
                {
                    type: "From SS2",
                    color: "bg-blue-600 text-blue-100"
                }
            ],
            pic: [
                {
                    type: "Zaki",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Irfan",
                    color: "bg-emerald-600 text-emerald-100"
                }
            ]
        },
        {
            id: "jb",
            data_local: "jb_local",
            data_other: "jb_other",
            name: "Johor Bharu",
            status: [
                {
                    type: "Pending",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Completed",
                    color: "bg-emerald-600 text-emerald-100"
                },
                {
                    type: "Pass Ampang",
                    color: "bg-red-600 text-red-100"
                },
                {
                    type: "From Ampang",
                    color: "bg-cyan-600 text-cyan-100"
                }
            ],
            pic: [
                {
                    type: "Dixon",
                    color: "bg-purple-600 text-purple-100"
                },
                {
                    type: "Ghost1",
                    color: "bg-emerald-600 text-emerald-100"
                }
            ]
        }
    ]
};
const initialInputState = {
    values: {
        search: ""
    }
};
const Branch = (props)=>{
    // Input handler -------------------
    const [inputValues, setInputValues] = (0,react_.useState)(initialInputState);
    const { values  } = inputValues;
    const inputChange = ({ target  })=>{
        setInputValues((prev)=>({
                ...prev,
                values: {
                    ...prev.values,
                    [target.name]: target.value
                }
            }));
    };
    // Search handler -------------------
    const [searchFocus, setSearchFocus] = (0,react_.useState)(false);
    const [searchValues] = (0,index_module/* useDebounce */.Nr)(values.search, 500);
    // console.log(searchValues);
    // Branch handler -------------------
    const pathname = (0,navigation.usePathname)();
    const [branchId, setBranchId] = (0,react_.useState)(null);
    const [branch, setBranch] = (0,react_.useState)(null);
    const [data, setData] = (0,react_.useState)([]);
    const [dataOther, setDataOther] = (0,react_.useState)([]);
    const [newEntry, setNewEntry] = (0,react_.useState)(false);
    // console.log(data);
    // console.log(newEntry);
    const [page, setPage] = (0,react_.useState)({
        local: {
            pageSize: 10,
            pageNum: 1,
            count: 0
        },
        other: {
            pageSize: 10,
            pageNum: 1,
            count: 0
        }
    });
    const handleSetPage = (id, obj)=>{
        if (id === "local") {
            setPage({
                ...page,
                local: obj
            });
        } else if (id === "other") {
            setPage({
                ...page,
                other: obj
            });
        }
    };
    // console.log(page, "pages");
    // console.log(Math.floor(page.count / page.pageSize) + 1, "check");
    (0,react_.useEffect)(()=>{
        const pathArray = pathname.split("/");
        const id = pathArray[pathArray.length - 1];
        if (id) {
            setBranchId(id);
        }
    }, [
        pathname
    ]);
    (0,react_.useEffect)(()=>{
        if (branch) {
            // console.log("fetched");
            fetchData(branch.data_local, page.local.pageSize, page.local.pageNum, searchValues).then((data)=>{
                setData(data.rows);
                setPage({
                    ...page,
                    local: {
                        ...page.local,
                        count: data.count
                    }
                });
            });
            fetchData(branch.data_other, page.other.pageSize, page.other.pageNum, searchValues).then((data)=>{
                setDataOther(data.rows);
                setPage({
                    ...page,
                    other: {
                        ...page.other,
                        count: data.count
                    }
                });
            });
        }
    }, [
        newEntry,
        branch,
        searchValues
    ]);
    (0,react_.useEffect)(()=>{
        if (branchId) {
            const branch = branchFormat.branch.find((b)=>b.id === branchId);
            setBranch(branch || null); // Handle undefined
        } else {
            setBranch(null); // Reset when branchId is not available
        }
    }, [
        branchId
    ]);
    // --------------------------
    // Update DB -----------
    const moveDB = async (toTable, id, value)=>{
        try {
            if (branch === null) return;
            await moveData(branch.data_local, branch.data_other, id);
            await updateData(branch.data_local, id, "status", value);
            await moveData(branch.data_local, branchFormat.branch[toTable].data_local, id);
            await deleteData(branch.data_local, id);
            setNewEntry(!newEntry);
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    const handleMoveDB = async (value, id)=>{
        try {
            if (branch === null) return;
            if (value === "Pass SS2") {
                if (branch.data_local === "ap_local") {
                    moveDB(1, id, "From Ampang");
                } else if (branch.data_local === "sa_local") {
                    moveDB(1, id, "From Setia Alam");
                }
            } else if (value === "Pass Ampang") {
                if (branch.data_local === "s2_local") {
                    moveDB(0, id, "From SS2");
                } else if (branch.data_local === "sa_local") {
                    moveDB(0, id, "From Setia Alam");
                } else if (branch.data_local === "jb_local") {
                    moveDB(0, id, "From JB");
                }
            } else if (value === "Pass Setia Alam") {
                if (branch.data_local === "ap_local") {
                    moveDB(2, id, "From Ampang");
                } else if (branch.data_local === "s2_local") {
                    moveDB(2, id, "From SS2");
                }
            } else if (value === "Pass JB") {
                if (branch.data_local === "ap_local") {
                    moveDB(3, id, "From Ampang");
                }
            }
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    const updateDB = async (id, column, value)=>{
        console.log("updated DB");
        try {
            if (branch) {
                if (column === "status") {
                    handleMoveDB(value, id);
                } else {
                    await updateData(branch.data_local, id, column, value);
                    setNewEntry(!newEntry);
                }
            }
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    const deleteDB = async (id)=>{
        console.log("deleted DB");
        try {
            if (branch) {
                await deleteData(branch.data_local, id);
                setNewEntry(!newEntry);
            }
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    const updateDBWithChanges = async (id, lastChange)=>{
        console.log("updated All DB");
        try {
            if (branch) {
                const changes = Object.keys(lastChange).reduce((acc, key)=>{
                    const value = lastChange[key];
                    if (value !== null) {
                        acc[key] = value;
                    }
                    return acc;
                }, {});
                if (Object.keys(changes).length > 0) {
                    await updateAllData(branch.data_local, id, changes);
                // Reset logic here if needed
                }
            }
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    const addDB = async ()=>{
        console.log("added DB");
        try {
            if (branch) {
                await addData(branch.data_local);
                setNewEntry(!newEntry);
            }
        } catch (error) {
            throw new Error(`Database error: ${error}`);
        }
    };
    // socket receiver ----
    (0,react_.useEffect)(()=>{
        const handleUnlockRow = ({ lock  })=>{
            if (lock === "" || lock === null) return;
            setNewEntry((prevNewEntry)=>!prevNewEntry);
        };
        const handleRender = ({ string  })=>{
            if (string === "" || string === null) return;
            // console.log("check");
            setNewEntry((prevNewEntry)=>!prevNewEntry);
        };
        lib_socket.on("unlock-row", handleUnlockRow);
        lib_socket.on("re-render", handleRender);
        return ()=>{
            lib_socket.off("unlock-row", handleUnlockRow);
            lib_socket.off("re-render", handleRender);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden md:flex flex-col gap-16 w-full px-16 py-4 bg-",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "top nav w-full flex justify-end",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Avatar, {
                            className: "rounded-full w-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(AvatarImage, {
                                    src: "https://idealtech.com.my/wp-content/uploads/2023/03/IDT_LOGO-150x150.png"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(AvatarFallback, {
                                    children: "IT"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "main-table flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                children: [
                                    branch?.name,
                                    " Warranty"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: `
              bg-transparent border-zinc-800 border-[1px] px-4 py-2 rounded-md flex gap-2 w-[250px]
              ${searchFocus ? "!border-zinc-400" : ""}`,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                width: "24",
                                                height: "24",
                                                viewBox: "0 0 24 24",
                                                className: "fill-white w-4",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396 1.414-1.414-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8 3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6-6-2.691-6-6 2.691-6 6-6z"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "text",
                                                value: values.search,
                                                name: "search",
                                                onChange: (e)=>inputChange(e),
                                                onBlur: ()=>{
                                                    setTimeout(()=>{
                                                        setSearchFocus(false);
                                                    }, 100);
                                                },
                                                onFocus: ()=>setSearchFocus(true),
                                                className: `bg-transparent outline-none w-full`,
                                                placeholder: "Search Service No"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex gap-4",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: `
                          px-4 py-2 rounded-md transition-all border-[1px]
                          bg-transparent border-zinc-600 text-zinc-600
                          mobilehover:hover:border-zinc-400 mobilehover:hover:text-zinc-400`,
                                                onClick: ()=>{
                                                    setTimeout(()=>{
                                                        setNewEntry(!newEntry);
                                                        console.log("pass");
                                                        lib_socket.emit("re-render", {
                                                            string: "render"
                                                        });
                                                    }, 50);
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Refresh Data"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: `
                          px-4 py-2 rounded-md transition-all border-[1px]
                          border-transparent bg-accent
                          mobilehover:hover:bg-accent/80`,
                                                onClick: ()=>{
                                                    addDB();
                                                    lib_socket.emit("re-render", {
                                                        string: "render"
                                                    });
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                        children: "New Entry"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_sections_Tables, {
                                id: "local",
                                branch: branch,
                                data: data,
                                updateDB: updateDB,
                                deleteDB: deleteDB,
                                updateAllDB: updateDBWithChanges,
                                setNewEntry: setNewEntry,
                                page: page.local,
                                handleSetPage: handleSetPage,
                                lockTable: false
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "other-table flex flex-col gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: "Other Branch Warranty"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex justify-between",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: `
              bg-transparent border-zinc-800 border-[1px] px-4 py-2 rounded-md flex gap-2 w-[250px]
              ${searchFocus ? "!border-zinc-400" : ""}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "24",
                                            height: "24",
                                            viewBox: "0 0 24 24",
                                            className: "fill-white w-4",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "M10 18a7.952 7.952 0 0 0 4.897-1.688l4.396 4.396 1.414-1.414-4.396-4.396A7.952 7.952 0 0 0 18 10c0-4.411-3.589-8-8-8s-8 3.589-8 8 3.589 8 8 8zm0-14c3.309 0 6 2.691 6 6s-2.691 6-6 6-6-2.691-6-6 2.691-6 6-6z"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "text",
                                            value: values.search,
                                            name: "search",
                                            onChange: (e)=>inputChange(e),
                                            onBlur: ()=>{
                                                setTimeout(()=>{
                                                    setSearchFocus(false);
                                                }, 100);
                                            },
                                            onFocus: ()=>setSearchFocus(true),
                                            className: `bg-transparent outline-none w-full`,
                                            placeholder: "Search Service No"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(_sections_Tables, {
                                id: "other",
                                branch: branch,
                                data: dataOther,
                                updateDB: updateDB,
                                deleteDB: deleteDB,
                                updateAllDB: updateDBWithChanges,
                                setNewEntry: setNewEntry,
                                page: page.other,
                                handleSetPage: handleSetPage,
                                lockTable: true
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:hidden flex justify-center items-center h-[100vh] text-center w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    children: "Use Desktop PC"
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Branch);


/***/ }),

/***/ 41733:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23424))

/***/ }),

/***/ 92587:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addData": () => (/* binding */ addData),
/* harmony export */   "deleteData": () => (/* binding */ deleteData),
/* harmony export */   "fetchData": () => (/* binding */ fetchData),
/* harmony export */   "moveData": () => (/* binding */ moveData),
/* harmony export */   "updateAllData": () => (/* binding */ updateAllData),
/* harmony export */   "updateData": () => (/* binding */ updateData)
/* harmony export */ });
/* harmony import */ var _lib_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21816);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15553);
/* __next_internal_action_entry_do_not_use__ fetchData,updateData,addData,deleteData,updateAllData,moveData */ 

async function fetchData(tableName, pageSize, pageNum, search) {
    try {
        const searchLike = `%${search}%`;
        const whereClause = search ? `WHERE service_no LIKE ?` : "";
        const query = `SELECT * FROM ?? ${whereClause} ORDER BY service_no DESC LIMIT ? OFFSET ?`;
        const queryParams = search ? [
            tableName,
            searchLike,
            pageSize,
            pageSize * (pageNum - 1)
        ] : [
            tableName,
            pageSize,
            pageSize * (pageNum - 1)
        ];
        const [rows] = await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query, queryParams);
        const countQuery = `SELECT COUNT(*) AS count FROM ??`;
        const [countRows] = await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(countQuery, [
            tableName
        ]);
        const count = countRows[0].count;
        return {
            rows: rows,
            count
        };
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
async function addData(tableName) {
    try {
        let prefix = "";
        if (tableName === "ap_local") {
            prefix = "WAP";
        } else if (tableName === "s2_local") {
            prefix = "WSS";
        } else if (tableName === "sa_local") {
            prefix = "WSA";
        } else if (tableName === "jb_local") {
            prefix = "WJB";
        }
        const year = new Date().getFullYear().toString().substr(-2); // Get the last two digits of the year
        const month = `0${new Date().getMonth() + 1}`.slice(-2); // Get the month in two-digit format
        // Query the database to find the last service_no for the current year and month
        const query = `
    SELECT service_no FROM ${tableName}
    WHERE service_no LIKE ?
    ORDER BY service_no DESC
    LIMIT 1
  `;
        const likePattern = `${prefix}${year}${month}%`;
        const [rows] = await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query, [
            likePattern
        ]);
        let sequenceNumber = 1; // Default sequence number
        if (rows.length > 0) {
            // Extract the numeric part of the service_no and increment it
            const lastSequenceNumber = parseInt(rows[0].service_no.slice(-3), 10);
            sequenceNumber = lastSequenceNumber + 1;
        }
        // Construct the service_no using the prefix, year, month, and next sequence number
        const serviceNo = `${prefix}${year}${month}${`00${sequenceNumber}`.slice(-3)}`;
        const today = new Date();
        const formattedDate = (0,date_fns__WEBPACK_IMPORTED_MODULE_1__.format)(today, "dd/MM/yyyy");
        const status = "Pending";
        const query2 = `INSERT INTO ${tableName} (service_no, date, status) VALUES (?, ?, ?)`;
        await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query2, [
            serviceNo,
            formattedDate,
            status
        ]);
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
async function updateData(tableName, id, column, value) {
    try {
        if (id != "") {
            const query = `UPDATE ${tableName} SET ?? = ? WHERE service_no = ?`;
            await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query, [
                column,
                value,
                id
            ]);
        }
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
async function deleteData(tableName, id) {
    try {
        if (id != "") {
            const query = `DELETE FROM ${tableName} WHERE service_no = ?`;
            await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query, [
                id
            ]);
        }
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
async function updateAllData(tableName, id, changes) {
    try {
        if (id != "") {
            const entries = Object.entries(changes);
            const setClause = entries.map(([column, value])=>`\`${column}\` = ?`).join(", ");
            const values = entries.map(([, value])=>value);
            if (setClause) {
                const query = `UPDATE ${tableName} SET ${setClause} WHERE service_no = ?`;
                await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(query, [
                    ...values,
                    id
                ]);
            }
        }
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
async function moveData(fromTable, toTable, id) {
    try {
        if (id != "") {
            const queryCheck = `SELECT * FROM ?? WHERE service_no = ?`;
            const check = await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(queryCheck, [
                toTable,
                id
            ]);
            if (check) {
                deleteData(toTable, id);
            }
            const queryMove = `INSERT INTO ?? SELECT * FROM ?? WHERE service_no = ?`;
            await _lib_mysql__WEBPACK_IMPORTED_MODULE_0__["default"].query(queryMove, [
                toTable,
                fromTable,
                id
            ]);
        }
    } catch (error) {
        throw new Error(`Database error: ${error}`);
    }
}
 // const API_URL = "https://intapi.idealtech.com.my";
 // const API_KEY = process.env.DB_API_KEY || ""; // Replace with your actual API key
 // async function insertData(tableName: string, data: MyDataType): Promise<any> {
 //   const response = await fetch(`${API_URL}/insert/${tableName}`, {
 //     method: "POST",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //     body: JSON.stringify(data),
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }
 // async function updateData(
 //   tableName: string,
 //   id: number,
 //   data: Partial<MyDataType>
 // ): Promise<any> {
 //   const response = await fetch(`${API_URL}/update/${tableName}/${id}`, {
 //     method: "PUT",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //     body: JSON.stringify(data),
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }
 // async function deleteData(tableName: string, id: number): Promise<any> {
 //   const response = await fetch(`${API_URL}/delete/${tableName}/${id}`, {
 //     method: "DELETE",
 //     headers: {
 //       "Content-Type": "application/json",
 //       "API-Key": API_KEY,
 //     },
 //   });
 //   if (!response.ok) {
 //     throw new Error(`Error: ${response.status}`);
 //   }
 //   return response.json();
 // }

(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_2__["default"])([
    fetchData,
    updateData,
    addData,
    deleteData,
    updateAllData,
    moveData
]);
fetchData.$$typeof = Symbol.for("react.server.reference");
fetchData.$$id = "d6cd588d7514364776479c7661673ea59a4bad44";
fetchData.$$bound = [];
fetchData.$$with_bound = false;
updateData.$$typeof = Symbol.for("react.server.reference");
updateData.$$id = "259e2160cba5040835d2eb2223d9fb19c42b2546";
updateData.$$bound = [];
updateData.$$with_bound = false;
addData.$$typeof = Symbol.for("react.server.reference");
addData.$$id = "026b647985a7041d6714a1b095d6b2d8bdb30183";
addData.$$bound = [];
addData.$$with_bound = false;
deleteData.$$typeof = Symbol.for("react.server.reference");
deleteData.$$id = "a55ea0dd0488cb9ddc99cb13ab894c7ca6f5dd4d";
deleteData.$$bound = [];
deleteData.$$with_bound = false;
updateAllData.$$typeof = Symbol.for("react.server.reference");
updateAllData.$$id = "456ce9565306f6b1aef3cbe0461daa5bd0d9701b";
updateAllData.$$bound = [];
updateAllData.$$with_bound = false;
moveData.$$typeof = Symbol.for("react.server.reference");
moveData.$$id = "eaaa23b96a05268298b7d5054d656dd16c0f1332";
moveData.$$bound = [];
moveData.$$with_bound = false;


/***/ }),

/***/ 383:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(35985);
module.exports = createProxy("D:\\220701_Danish Files\\02 Projects\\200000_Website Design\\Idealtech\\01_PC_Builder\\idt-intapp\\app\\warranty\\[branch]\\page.tsx");


/***/ }),

/***/ 21816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(62418);
/* harmony import */ var mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2_promise__WEBPACK_IMPORTED_MODULE_0__);

const connection = mysql2_promise__WEBPACK_IMPORTED_MODULE_0___default().createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connection);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [961,740,27,693,147,500], () => (__webpack_exec__(84106)));
module.exports = __webpack_exports__;

})();